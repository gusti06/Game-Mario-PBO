#!/usr/bin/env python
__author__ = 'mrd4x'

import sys
import pygame as pg
from data.main import main
import cProfile


if __name__=='__main__':
    main()
    pg.quit()
    sys.exit()